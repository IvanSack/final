package repository;

@Repository
public interface DomicilioRepository extends JpaRepository<Domicilio, Long> {
}
