package repository;
@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
