package repository;

@Repository
public interface TurnoRepository extends JpaRepository<Turno, Long> {
}
