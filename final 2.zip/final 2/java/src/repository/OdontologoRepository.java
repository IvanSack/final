package repository;

p@Repository
public interface OdontologoRepository extends JpaRepository<Odontologo, Long> {
}
